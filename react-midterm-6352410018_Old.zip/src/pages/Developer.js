import React from "react";
import Kantz from "../images/Kantz.jpg";

const Developer = () => {
  return (
    <div style={{ textAlign: "center" }}>
      <img src={Kantz} style={{ maxWidth: "10%" }} />
      <h3>6352410018</h3>
      <h3>นายไกรสร กุ่ยรักษา</h3>
      <h3>Kraisorn Kuiraksa</h3>
      <h3>เบอร์โทร : 0918032703 </h3>
    </div>
  );
};

export default Developer;
