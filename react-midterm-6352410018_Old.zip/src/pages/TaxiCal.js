import React, { useState } from "react";
import Taxi from "../images/5444.jpg";

const TaxiCal = () => {
  const [distance, setDistance] = useState(0);
  const [time, setTime] = useState(0);
  const [result, setResult] = useState(0);

  const calTaxi = () => {
    let result = 0;
    if (distance >= 0 && distance <= 1) {
      result = 40;
    } else if (distance > 1 && distance <= 10) {
      result = 40 + (distance - 1) * 6.5;
    } else if (distance > 10 && distance <= 20) {
      result = 40 + 9.5 + (distance - 10) * 7;
    } else if (distance > 20 && distance <= 40) {
      result = 40 + 9.5 + 7 + (distance - 20) * 8;
    } else if (distance > 40 && distance <= 60) {
      result = 40 + 9.5 + 7 + 32 + (distance - 40) * 8.5;
    } else if (distance > 60 && distance <= 80) {
      result = 40 + 9.5 + 7 + 32 + 32 + (distance - 60) * 9;
    } else if (distance > 80) {
      result = 40 + 9.5 + 7 + 32 + 32 + 32 + (distance - 80) * 10.5;
    }
    result = result + time * 3;
    setResult(result);
  };

  return (
    <div style={{ textAlign: "center" }}>
      <img src={Taxi} style={{ maxWidth: "10%" }} />
      <h3>คำนวณค่าแท็กซี่</h3>
      <input
        type="number"
        placeholder="ระยะทาง (กิโลเมตร)"
        onChange={(e) => setDistance(e.target.value)}
      />
      <br />
      <input
        type="number"
        placeholder="เวลาที่รถติด (นาที)"
        onChange={(e) => setTime(e.target.value)}
      />
      <br />
      <button onClick={calTaxi}>คำนวณค่าแท็กซี่</button>
      <h3>ค่าแท็กซี่ที่คำนวณได้ {result} บาท</h3>
    </div>
  );
};

export default TaxiCal;
