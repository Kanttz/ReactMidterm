import React from "react";

const FooterExam = () => {
  return (
    <>
      <div className="footer" style={{ textAlign: "center" }}>
        <hr style={{ width: "80%", height: "2px", color: "black" }} />
        <h3>Computer Science-Digital Technology and Innovation</h3>
        <h3>มหาวิทยาลัยเอเชียอาค์เนย์</h3>
      </div>
    </>
  );
};

export default FooterExam;
